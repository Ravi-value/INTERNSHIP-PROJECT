// let num =prompt("enter a nunber");

// if (num % 5 ===0){
//     console.log(num,"nuber is multiple of 5");
// }
// else{
//     console.log(num,"number is not multiple of 5");
// }

// let name = "ravishankhwar" ;
// size = 0;
// for(let val of name){
//     console.log(val);
//     size++;
// }
// console.log("size of string is",size);
 //// only use for string

 //// fo objects(dictionaries) we use for in loop

// let person = {
//     name : "ravishankhwar",
//     age : 22,
//     city : "delhi",
//     population : 1000000
// };
// for(let key in person){
//     console.log(key,":",person[key]);
//     console.log(person.key); // this give undefined because key is not a property of person object

// }   

// console.log(person.name); // this give 


// /////////////////templet literals

// console.log(`my name is ${person.name} and i am ${person.age} years old`);
// console.log("my name is "+person.name+" and i am "+person.age+" years old");
// ////both uper lines will give same output but templet literals is more readable and easy to write