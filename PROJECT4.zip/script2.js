const loginForm = document.querySelector(".loginForm");
const registerForm = document.querySelector(".registerForm");

const showRegister = document.querySelector(".register1");
const showLogin = document.getElementById("showLogin");

showRegister.addEventListener("click", (e) => {
    e.preventDefault();
    loginForm.classList.add("hide");
    registerForm.classList.remove("hide");
});

showLogin.addEventListener("click", (e) => {
    e.preventDefault();
    registerForm.classList.add("hide");
    loginForm.classList.remove("hide");
});