
const swiper = new Swiper(".mySwiper", {
    loop: true,
    navigation: {
        nextEl: "#next",
        prevEl: "#prev",
    },
});

const cartIcon = document.querySelector(".cart-icon");
const cartTab = document.querySelector(".card-tab");
const close = document.querySelector('.close');
const cardList = document.querySelector('.order-card');
const orderCard = document.querySelector('.cart-list');
const cardTotal = document.querySelector('.cart-total');
const cartValue = document.querySelector('.cart-value');
const mobilemanu =document.querySelector('.nav-links-mobile');
const hamburger =document.querySelector('.hamburger');
const seeMore = document.querySelector('.seemore');
const btnmobile = document.querySelector('.btn-mobile');


cartIcon.addEventListener('click', (m) => { m.preventDefault(); cartTab.classList.add('cart-tab-active') });
close.addEventListener('click', (m) => { m.preventDefault(); cartTab.classList.remove('cart-tab-active') });
hamburger.addEventListener("click", (e) => {
    e.preventDefault();
    mobilemanu.classList.toggle("active");
});

seeMore.addEventListener("click", (e) => {
    e.preventDefault();

    cardList.classList.toggle("new");

    if (cardList.classList.contains("new")) {
        seeMore.innerHTML = 'Show Less <i class="fa-solid fa-arrow-left-long"></i>';
    } else {
        seeMore.innerHTML = 'See More <i class="fa-solid fa-arrow-right-long"></i>';
    }
});



let productList = [
    {
        id: 1,
        name: "Double Cheese Burger",
        price: "₹200",
        image: "images/burger.png",
    },
    {
        id: 2,
        name: "Cheese Pizza",
        price: "₹350",
        image: "images/pizza.png",
    },
    {
        id: 3,
        name: "Chicken Sandwich",
        price: "₹180",
        image: "images/sandwich.png",
    },
    {
        id: 4,
        name: "Chicken Roll",
        price: "₹220",
        image: "images/chicken-roll.png",
    },
    {
        id: 5,
        name: "Fried Chicken",
        price: "₹280",
        image: "images/fried-chicken.png",
    },
    {
        id: 6,
        name: "Spring Roll",
        price: "₹160",
        image: "images/spring-roll.png",
    },
    {
        id: 7,
        name: "Spaghetti",
        price: "₹250",
        image: "images/spaghetti.png",
    },
    {
        id: 8,
        name: "Lasagna",
        price: "₹320",
        image: "images/lasagna.png",
    },
    {
        id: 9,
        name: "Masala Dosa",
        price: "₹180",
        image: "images/dosa.png",
    },
    {
        id: 10,
        name: "Chocolate Cake",
        price: "₹250",
        image: "images/cake.png",
    },
    {
        id: 11,
        name: "Chinese Noodles",
        price: "₹220",
        image: "images/chinese.png",
    },
    {
        id: 12,
        name: "Fresh Juice",
        price: "₹120",
        image: "images/juice.png",
    },
    {
        id: 13,
        name: "Green Salad",
        price: "₹160",
        image: "images/salad.png",
    },
    {
        id: 14,
        name: "Pasta",
        price: "₹240",
        image: "images/pasta.png",
    },
    {
        id: 15,
        name: "Roll",
        price: "₹180",
        image: "images/roll.png",
    },
    {
        id: 16,
        name: "Veg Cutlet",
        price: "₹170",
        image: "images/cutlet.png",
    },
    {
        id: 17,
        name: "Pottichur",
        price: "₹320",
        image: "images/pottichur.png",
    },
    {
        id: 18,
        name: "South Indian Meal",
        price: "₹280",
        image: "images/south-indian.png",
    },
    {
        id: 19,
        name: "Chicken Biryani",
        price: "₹350",
        image: "images/biryani.png",
    },
    {
        id: 20,
        name: "Chicken Shawarma",
        price: "₹220",
        image: "images/shawarma.png",
    },
    {
        id: 21,
        name: "Veg Momos",
        price: "₹180",
        image: "images/momo.png",
    },
    {
        id: 22,
        name: "Belgian Waffles",
        price: "₹260",
        image: "images/desserts.png",
    },
    {
        id: 23,
        name: "Medu Vada",
        price: "₹140",
        image: "images/vada.png",
    },
    {
        id: 24,
        name: "Kerala Parotta",
        price: "₹90",
        image: "images/parotta.png",
    }
];

let cardProduct = [];

const updateTotal = () => {
    let totalPrice = 0;
    let totalQuelity = 0;

    document.querySelectorAll('.items').forEach(item => {

        const quantity = parseInt(
            item.querySelector('.quantity-value').textContent
        );
        const price = parseInt(
            item.querySelector('.netprice').textContent.replace('₹', '')
        );

        totalPrice += price;
        totalQuelity += quantity;
    });

    cardTotal.textContent = `₹${totalPrice}`;
    cartValue.textContent = totalQuelity;

};


productList.forEach(product => {

    const orderCard = document.createElement('div');
    orderCard.classList.add('card-image');
    orderCard.innerHTML = `
        <img src="${product.image}" alt="Burger">
        <h4>${product.name}</h4>
        <h4 class="price">${product.price}</h4>
        <a href="#" class="btn-order" >Add to Cart</a>
                                `;
    cardList.appendChild(orderCard);
    updateTotal();



    const cardbtn = orderCard.querySelector('.btn-order');
    cardbtn.addEventListener('click', (e) => {
        e.preventDefault();
        // let cartvalue = document.querySelector('.cart-value');
        // console.dir(cartvalue)
        // cartvalue.innercontent= cartvalue.childNodes.odeList[1].data++;

        addToCart(product);
        updateTotal();
    })
})




const addToCart = (product) => {
    const existingProduct = cardProduct.find(item => item.id === product.id);
    if (existingProduct) {
        alert('Item Already exist in card');
        return;
    };

    cardProduct.push(product);
    let quntity = 1;
    let price = parseFloat(product.price.replace('₹', ''));
    const cardList2 = document.createElement('div');
    cardList2.classList.add('items');
    cardList2.innerHTML = `
        <div style="display: flex; align-items: center;">
                                            <img src="${product.image}">
                                            <div class="card-list-content1">
                                                <h4>${product.name}</h4>
                                                <h4 class="netprice">${product.price}</h4>
                                            </div>
                                        </div>
                                        <div class="card-list-content2">
                                            <a href="#" class="quentity-btn minus">
                                                <i class="fa-solid fa-minus"></i>
                                            </a>
                                            <h4 class="quantity-value ">${quntity}</h4>
                                            <a href="#" class="quentity-btn plus">
                                                <i class="fa-solid fa-plus"></i>
                                            </a>
                                        </div>
        `

    orderCard.appendChild(cardList2);
    const quantityValue = cardList2.querySelector('.quantity-value');
    const netprice = cardList2.querySelector('.netprice');
    const plusBtn = cardList2.querySelector('.plus');
    const minusBtn = cardList2.querySelector('.minus');


    plusBtn.addEventListener('click', (m) => {
        m.preventDefault();
        quntity++;
        quantityValue.textContent = quntity;
        netprice.textContent = `₹${price * quntity}`;
        updateTotal();
    })

    minusBtn.addEventListener('click', (m) => {
        m.preventDefault();
        if (quntity > 1) {
            quntity--;
            quantityValue.textContent = quntity;
            netprice.textContent = `₹${price * quntity}`;
            updateTotal();
        }
        else {
            cardList2.classList.add('slide-out')
            setTimeout(() => {

                cardList2.remove();
                cardProduct = cardProduct.filter(items => items.id !== product.id);
                updateTotal();
            }, 300)


        }

    })

}



const goPage = document.getElementById("goPage");

goPage.addEventListener("click", (e) => {
    e.preventDefault();
    window.location.href = "index2.html";
});