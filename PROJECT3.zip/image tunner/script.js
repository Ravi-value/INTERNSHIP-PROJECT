const filtersContainer = document.querySelector(".filter");
let filters = {
    brightness: {
        value: 100,
        min: 0,
        max: 200,
        step: 1,
        unit: "%"
    },
    contrast: {
        value: 100,
        min: 0,
        max: 200,
        step: 1,
        unit: "%"
    },
    saturate: {
        value: 100,
        min: 0,
        max: 200,
        step: 1,
        unit: "%"
    },
    grayscale: {
        value: 0,
        min: 0,
        max: 100,
        step: 1,
        unit: "%"
    },
    sepia: {
        value: 0,
        min: 0,
        max: 100,
        step: 1,
        unit: "%"
    },
    blur: {
        value: 0,
        min: 0,
        max: 20,
        step: 1,
        unit: "px"
    },
    hueRotate: {
        value: 0,
        min: 0,
        max: 360,
        step: 1,
        unit: "deg"
    },
    invert: {
        value: 0,
        min: 0,
        max: 100,
        step: 1,
        unit: "%"
    },
    opacity: {
        value: 100,
        min: 0,
        max: 100,
        step: 1,
        unit: "%"
    },
    rotate: {
        value: 0,
        min: -180,
        max: 180,
        step: 1,
        unit: "deg"
    },
    scale: {
        value: 1,
        min: 0.5,
        max: 2,
        step: 0.01,
        unit: ""
    },

    flipX: {
        value: 1,
        min: -1,
        max: 1,
        step: 2,
        unit: ""
    },
    flipY: {
        value: 1,
        min: -1,
        max: 1,
        step: 2,
        unit: ""
    }
};


const imageCanvas = document.querySelector("#img-canvas");
const imgInput = document.querySelector("#image-input");
const canvasCtx = imageCanvas.getContext("2d");
let file = null;
let image = null;
const reset = document.querySelector("#reset");
const download = document.querySelector("#download");
const presetsCotainer = document.querySelector(".preset");

function createFilterElement(name, unit = "%", value, min, max) {
    const div = document.createElement("div");
    div.classList.add("filter");
    const input = document.createElement("input");
    input.type = "range";
    input.min = min;
    input.max = max;
    input.value = value;
    input.id = name;

    const p = document.createElement("p");
    p.innerText = name;

    div.appendChild(p);
    div.appendChild(input);
    input.addEventListener("input", (event) => {
        filters[name].value = input.value;
        applyFilters();
    });

    return div
}
function createFilter() {
    Object.keys(filters).forEach(key => {
        const filterElement = createFilterElement(key, filters[key].unit, filters[key].value, filters[key].min, filters[key].max, filters[key].step);

        filtersContainer.appendChild(filterElement);
    });
};
createFilter();

imgInput.addEventListener("change", (event) => {
    const file = event.target.files[0];
    const img = new Image();
    img.src = URL.createObjectURL(file);

    const pholder = document.querySelector(".placeholder");
    imageCanvas.style.display = "block";
    pholder.style.display = "none";

    img.onload = () => {
        image = img;
        imageCanvas.width = img.width;
        imageCanvas.height = img.height;
        applyFilters();
    };
})

function applyFilters() {
    if (!image) return;
    // canvasCtx.filter = `brightness(${filters.brightness.value}${filters.brightness.unit})`
    canvasCtx.clearRect(0, 0, imageCanvas.width, imageCanvas.height);

    canvasCtx.filter = `
    brightness(${filters.brightness.value}${filters.brightness.unit})
    contrast(${filters.contrast.value}${filters.contrast.unit})
    saturate(${filters.saturate.value}${filters.saturate.unit})
    grayscale(${filters.grayscale.value}${filters.grayscale.unit})
    sepia(${filters.sepia.value}${filters.sepia.unit})
    blur(${filters.blur.value}${filters.blur.unit})
    hue-rotate(${filters.hueRotate.value}${filters.hueRotate.unit})
    invert(${filters.invert.value}${filters.invert.unit})
    opacity(${filters.opacity.value}${filters.opacity.unit})
`;
    // canvasCtx.drawImage(image, 0, 0, imageCanvas.width, imageCanvas.height);
    canvasCtx.save();
    canvasCtx.translate(imageCanvas.width / 2, imageCanvas.height / 2);
    canvasCtx.rotate(filters.rotate.value * Math.PI / 180);

    // Scale + Flip
    canvasCtx.scale(
        filters.scale.value * filters.flipX.value,
        filters.scale.value * filters.flipY.value
    );
    canvasCtx.drawImage(
        image,
        -imageCanvas.width / 2,
        -imageCanvas.height / 2,
        imageCanvas.width,
        imageCanvas.height
    );
    canvasCtx.restore();

}

reset.addEventListener("click", () => {
    filters = {
        brightness: {
            value: 100,
            min: 0,
            max: 200,
            step: 1,
            unit: "%"
        },
        contrast: {
            value: 100,
            min: 0,
            max: 200,
            step: 1,
            unit: "%"
        },
        saturate: {
            value: 100,
            min: 0,
            max: 200,
            step: 1,
            unit: "%"
        },
        grayscale: {
            value: 0,
            min: 0,
            max: 100,
            step: 1,
            unit: "%"
        },
        sepia: {
            value: 0,
            min: 0,
            max: 100,
            step: 1,
            unit: "%"
        },
        blur: {
            value: 0,
            min: 0,
            max: 20,
            step: 1,
            unit: "px"
        },
        hueRotate: {
            value: 0,
            min: 0,
            max: 360,
            step: 1,
            unit: "deg"
        },
        invert: {
            value: 0,
            min: 0,
            max: 100,
            step: 1,
            unit: "%"
        },
        opacity: {
            value: 100,
            min: 0,
            max: 100,
            step: 1,
            unit: "%"
        },
        rotate: {
            value: 0,
            min: -180,
            max: 180,
            step: 1,
            unit: "deg"
        },
        scale: {
            value: 1,
            min: 0.1,
            max: 3,
            step: 0.1,
            unit: ""
        },
        flipX: {
            value: 1,
            min: -1,
            max: 1,
            step: 2,
            unit: ""
        },
        flipY: {
            value: 1,
            min: -1,
            max: 1,
            step: 2,
            unit: ""
        }
    };
    applyFilters();
    filtersContainer.innerHTML = "";
    createFilter();
})

download.addEventListener("click", () => {
    const link = document.createElement("a");
    link.download = "edited-image.png";
    link.href = imageCanvas.toDataURL()
    link.click();
});

const presets = {
    normal: {
        brightness: 100,
        contrast: 100,
        saturate: 100,
        grayscale: 0,
        sepia: 0,
        blur: 0,
        hueRotate: 0,
        invert: 0,
        opacity: 100
    },

    vintage: {
        brightness: 110,
        contrast: 120,
        saturate: 80,
        grayscale: 20,
        sepia: 60,
        blur: 0,
        hueRotate: 10,
        invert: 0,
        opacity: 100
    },

    blackWhite: {
        brightness: 100,
        contrast: 140,
        saturate: 0,
        grayscale: 100,
        sepia: 0,
        blur: 0,
        hueRotate: 0,
        invert: 0,
        opacity: 100
    },

    warm: {
        brightness: 110,
        contrast: 105,
        saturate: 130,
        grayscale: 0,
        sepia: 20,
        blur: 0,
        hueRotate: 15,
        invert: 0,
        opacity: 100
    },

    cool: {
        brightness: 105,
        contrast: 110,
        saturate: 140,
        grayscale: 0,
        sepia: 0,
        blur: 0,
        hueRotate: 180,
        invert: 0,
        opacity: 100
    },

    vivid: {
        brightness: 115,
        contrast: 140,
        saturate: 180,
        grayscale: 0,
        sepia: 0,
        blur: 0,
        hueRotate: 0,
        invert: 0,
        opacity: 100
    },

    faded: {
        brightness: 115,
        contrast: 80,
        saturate: 70,
        grayscale: 10,
        sepia: 10,
        blur: 1,
        hueRotate: 0,
        invert: 0,
        opacity: 90
    },

    dreamy: {
        brightness: 120,
        contrast: 90,
        saturate: 120,
        grayscale: 0,
        sepia: 15,
        blur: 3,
        hueRotate: 10,
        invert: 0,
        opacity: 100
    },

    cinematic: {
        brightness: 95,
        contrast: 160,
        saturate: 90,
        grayscale: 0,
        sepia: 10,
        blur: 0,
        hueRotate: 190,
        invert: 0,
        opacity: 100
    },

    negative: {
        brightness: 100,
        contrast: 110,
        saturate: 100,
        grayscale: 0,
        sepia: 0,
        blur: 0,
        hueRotate: 0,
        invert: 100,
        opacity: 100
    }
};

Object.keys(presets).forEach(presetName => {
    const presetButton = document.createElement("button");
    presetButton.classList.add("btn")
    presetButton.innerText = presetName;
    presetsCotainer.appendChild(presetButton);

    presetButton.addEventListener('click', () => {
        const preset = presets[presetName];
        Object.keys(preset).forEach(filterName => {
            filters[filterName].value = preset[filterName];
        })
        applyFilters();
    })
})